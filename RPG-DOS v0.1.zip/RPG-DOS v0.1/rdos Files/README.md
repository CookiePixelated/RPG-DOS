##Title
RPG-DOS

##Description
Hello, User
You are now hired as a Adventurer.
Defeat Monsters and gain plentiful of EXPs.
Farm crops and gain coins to have physical needs
like Levels, Additional HP, Lives, and more!
Beware of spending your lives for fighting or you'll lose all your progress!

##Installing Instructions
Trying to play the game? 

disable the smartscreen or click the "More info" and click the drop-down button and click "Run anyway" and it should be good to go!

##Email
Bugs? Suggestions?
Tell me at
ulannags@gmail.com